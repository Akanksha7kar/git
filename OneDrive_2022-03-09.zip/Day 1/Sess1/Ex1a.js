const x = 10,y = 20;
x = 30;
const result = (x,y)=>{
   return x+y;
};

const Subtract = function(x,y)
{
  return x-y;
}

console.log(Subtract(10,20));
console.log(result(10,20));