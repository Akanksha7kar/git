const x = 10,y = 20;

function Add(x,y)
{
  return x+y;
}

const result = Add(x,y);

console.log(result);