var message = "Hi from Viren";

const showMessage = ()=>{console.log(message)};

showMessage();